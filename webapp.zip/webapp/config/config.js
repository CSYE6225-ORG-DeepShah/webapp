module.exports = {
    HOST: '127.0.0.1',
    USER: 'root',
    PASSWORD: 'shahdeep',
    DB: 'Cloud',
    dialect: 'mysql',
};